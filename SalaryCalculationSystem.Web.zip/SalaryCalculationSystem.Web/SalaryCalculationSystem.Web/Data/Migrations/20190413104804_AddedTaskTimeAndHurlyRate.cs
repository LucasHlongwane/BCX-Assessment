﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SalaryCalculationSystem.Web.Data.Migrations
{
    public partial class AddedTaskTimeAndHurlyRate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "HourlyRate",
                table: "DailyTasks",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.AddColumn<int>(
                name: "TaskTime",
                table: "DailyTasks",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "HourlyRate",
                table: "DailyTasks");

            migrationBuilder.DropColumn(
                name: "TaskTime",
                table: "DailyTasks");
        }
    }
}
