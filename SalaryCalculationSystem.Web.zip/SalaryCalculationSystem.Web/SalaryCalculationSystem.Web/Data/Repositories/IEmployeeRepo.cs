﻿using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalaryCalculationSystem.Web.Data.Repositories
{
    public interface IEmployeeRepo
    {
        IEnumerable<Employee> GetAllEmployees();
        IEnumerable<EmployeeRole> GetRoles();
        Employee GetEmployee(int id);
        void AddEmployee(Employee employee);
        void RemoveEmployee(Employee employee);
        void UpdateEmployee(Employee employee);
        void SaveChange();
    }
}
