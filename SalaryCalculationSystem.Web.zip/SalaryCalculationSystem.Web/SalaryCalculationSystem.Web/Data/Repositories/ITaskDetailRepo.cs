﻿using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalaryCalculationSystem.Web.Data.Repositories
{
    public interface ITaskDetailRepo
    {
        IEnumerable<TaskDetail> GetAllTasks();
        TaskDetail GetTask(int id);
        void AddTask(TaskDetail taskDetail);
        void RemoveTask(TaskDetail taskDetail);
        void SaveChanges();
    }
}
