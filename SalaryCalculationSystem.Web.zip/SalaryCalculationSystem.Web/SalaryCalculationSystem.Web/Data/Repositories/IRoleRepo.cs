﻿using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalaryCalculationSystem.Web.Data.Repositories
{
    public interface IRoleRepo
    {
        IEnumerable<EmployeeRole> GetAllRoles();
        EmployeeRole GetRole(int id);
        void AddRole(EmployeeRole role);
        void RemoveRole(EmployeeRole role);
        void UpdateRole(EmployeeRole role);
        void SaveChanges();
    }
}
