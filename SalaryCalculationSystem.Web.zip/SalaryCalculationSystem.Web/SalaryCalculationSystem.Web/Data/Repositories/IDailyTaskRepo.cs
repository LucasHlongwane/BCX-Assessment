﻿using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalaryCalculationSystem.Web.Data.Repositories
{
    public interface IDailyTaskRepo
    {
        //change to IQuerable and/or IEnumarable
        /// <summary>
        /// List cannot handle queris of big data. It stores the whole data pulled into the memory. Reducing performance.
        /// </summary>
        /// <returns></returns>
        IEnumerable<DailyTask> GetAllTasks();
        IEnumerable<DailyTask> GetTaskByEmployee(int id);
        IEnumerable<Employee> GetEmployee();
        IEnumerable<TaskDetail> GetTasks();
        DailyTask GetTask(int id);
        void AddTask(DailyTask dailyTask);
        void RemoveTask(DailyTask dailyTask);
        void UpdateTask(DailyTask dailyTask);
        void SaveChanges();
    }
}
