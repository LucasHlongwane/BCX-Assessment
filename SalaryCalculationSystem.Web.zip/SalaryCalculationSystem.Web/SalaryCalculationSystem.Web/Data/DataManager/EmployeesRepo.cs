﻿using Microsoft.EntityFrameworkCore;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalaryCalculationSystem.Web.Data.DataManager
{
    public class EmployeesRepo : IEmployeeRepo
    {
        private readonly ApplicationDbContext _context;

        public EmployeesRepo(ApplicationDbContext context)
        {
            _context = context;
        }

        public void AddEmployee(Employee employee) =>
            _context.Employees.Add(employee);

        public IEnumerable<Employee> GetAllEmployees() =>
            _context.Employees.Include(a => a.EmployeeRole).ToList();


        public Employee GetEmployee(int id) =>
            _context.Employees.Include(a => a.EmployeeRole).SingleOrDefault(b => b.EmployeeId == id);

        public IEnumerable<EmployeeRole> GetRoles() =>
            _context.EmployeeRoles.ToList();

        public void RemoveEmployee(Employee employee) =>
            _context.Employees.Remove(employee);

        public void SaveChange() =>
            _context.SaveChangesAsync();

        public async void UpdateEmployee(Employee employee)
        {
            if (_context != null)
            {
                _context.Employees.Update(employee);

                 _context.SaveChangesAsync();
            }
        }
    }
}
