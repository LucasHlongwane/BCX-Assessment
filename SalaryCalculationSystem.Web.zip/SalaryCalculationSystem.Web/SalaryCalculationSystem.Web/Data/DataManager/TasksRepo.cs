﻿using Microsoft.EntityFrameworkCore;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalaryCalculationSystem.Web.Data.DataManager
{
    public class TasksRepo : ITaskDetailRepo
    {
        private readonly ApplicationDbContext _context;

        public TasksRepo(ApplicationDbContext context)
        {
            _context = context;
        }

        public void AddTask(TaskDetail taskDetail) =>
             _context.TaskDetails.Add(taskDetail);


        public IEnumerable<TaskDetail> GetAllTasks() =>
            _context.TaskDetails.ToList();


        public TaskDetail GetTask(int id) =>
            _context.TaskDetails.SingleOrDefault(b => b.TaskId == id);



        public void RemoveTask(TaskDetail taskDetail) =>
            _context.TaskDetails.Remove(taskDetail);


        public void SaveChanges() =>
            _context.SaveChangesAsync();
    }
}
