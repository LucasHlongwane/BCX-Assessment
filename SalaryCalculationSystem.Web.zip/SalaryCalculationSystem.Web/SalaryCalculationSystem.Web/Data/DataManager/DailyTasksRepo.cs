﻿using Microsoft.EntityFrameworkCore;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalaryCalculationSystem.Web.Data.DataManager
{
    public class DailyTasksRepo : IDailyTaskRepo
    {
        private readonly ApplicationDbContext _context;

        public DailyTasksRepo(ApplicationDbContext context)
        {
            _context = context;
        }

        public void AddTask(DailyTask dailyTask) =>
            _context.DailyTasks.Add(dailyTask);

        public IEnumerable<Employee> GetEmployee() =>
            _context.Employees.ToList();

        public IEnumerable<TaskDetail> GetTasks() =>
            _context.TaskDetails.ToList();

        public IEnumerable<DailyTask> GetAllTasks() =>
            _context.DailyTasks.Include(a => a.TaskDetail).Include(a => a.Employee).ToList();


        public DailyTask GetTask(int id) =>
            _context.DailyTasks.Include(a => a.TaskDetail).Include(a => a.Employee).SingleOrDefault(b => b.DailyTaskId == id);

        public IEnumerable<DailyTask> GetTaskByEmployee(int id) =>
            _context.DailyTasks.Include(a => a.TaskDetail).Include(a => a.Employee).Where(t => t.EmployeeRef == id);


        public void RemoveTask(DailyTask dailyTask) =>
            _context.DailyTasks.Remove(dailyTask);


        public void SaveChanges() =>
            _context.SaveChangesAsync();

        public void UpdateTask(DailyTask dailyTask)
        {
            if (_context != null)
            {
                _context.DailyTasks.Update(dailyTask);

                _context.SaveChangesAsync();
            }
        }

        public Employee GetRoleID(int id)
        {
            return _context.Employees.SingleOrDefault(a => a.EmployeeId == id);
            
        }

    }
}
