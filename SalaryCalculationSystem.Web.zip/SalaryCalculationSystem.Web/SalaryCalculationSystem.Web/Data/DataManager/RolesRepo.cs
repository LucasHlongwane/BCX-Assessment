﻿using Microsoft.EntityFrameworkCore;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalaryCalculationSystem.Web.Data.DataManager
{
    public class RolesRepo : IRoleRepo
    {
        private readonly ApplicationDbContext _context;

        public RolesRepo(ApplicationDbContext context)
        {
            _context = context;
        }


        public void AddRole(EmployeeRole role) =>
            _context.EmployeeRoles.Add(role);


        public IEnumerable<EmployeeRole> GetAllRoles() =>
            _context.EmployeeRoles.ToList();


        public EmployeeRole GetRole(int id) =>
            _context.EmployeeRoles.SingleOrDefault(a => a.RoldeId == id);


        public void RemoveRole(EmployeeRole role) =>
            _context.EmployeeRoles.Remove(role);


        public void SaveChanges() =>
            _context.SaveChangesAsync();

        public void UpdateRole(EmployeeRole role)
        {
            if (_context != null)
            {
                _context.EmployeeRoles.Update(role);

                _context.SaveChangesAsync();

            }
        }
    }
}
