﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SalaryCalculationSystem.Web.Data;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;

namespace SalaryCalculationSystem.Web.Controllers
{
    public class EmployeeRolesController : Controller
    {
        private readonly IRoleRepo _roleRepo;

        public EmployeeRolesController(IRoleRepo roleRepo)
        {
            _roleRepo = roleRepo;
        }

        // GET: EmployeeRoles
        public async Task<IActionResult> Index()
        {
            return View(_roleRepo.GetAllRoles());

        }

        // GET: EmployeeRoles/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeRole = _roleRepo.GetRole(id.Value);
            if (employeeRole == null)
            {
                return NotFound();
            }

            return View(employeeRole);
        }

        // GET: EmployeeRoles/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: EmployeeRoles/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RoldeId,RoleName,Rate")] EmployeeRole employeeRole)
        {
            if (ModelState.IsValid)
            {
                _roleRepo.AddRole(employeeRole);
                _roleRepo.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employeeRole);
        }

        // GET: EmployeeRoles/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeRole = _roleRepo.GetRole(id.Value);
            if (employeeRole == null)
            {
                return NotFound();
            }
            return View(employeeRole);
        }

        // POST: EmployeeRoles/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("RoldeId,RoleName,Rate")] EmployeeRole employeeRole)
        {
            if (id != employeeRole.RoldeId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    //_context.Update(employeeRole);
                    _roleRepo.UpdateRole(employeeRole);
                }
                catch (DbUpdateConcurrencyException)
                {
                    return NotFound();
                    
                }
                return RedirectToAction(nameof(Index));
            }
            return View(employeeRole);
        }

        // GET: EmployeeRoles/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employeeRole = _roleRepo.GetRole(id.Value);
            if (employeeRole == null)
            {
                return NotFound();
            }

            return View(employeeRole);
        }

        // POST: EmployeeRoles/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employeeRole = _roleRepo.GetRole(id);
            _roleRepo.RemoveRole(employeeRole);
            _roleRepo.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
