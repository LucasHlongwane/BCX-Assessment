﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SalaryCalculationSystem.Web.Data;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;

namespace SalaryCalculationSystem.Web.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly IEmployeeRepo _employeeRepository;
        private readonly IDailyTaskRepo _dailyTaskRepository;

        public EmployeesController(IEmployeeRepo employeeRepository, IDailyTaskRepo dailyTaskRepository)
        {
            _employeeRepository = employeeRepository;
            _dailyTaskRepository = dailyTaskRepository;
        }

        // GET: Employees
        public ActionResult Index()
        {
            return View(_employeeRepository.GetAllEmployees());
        }

        // GET: Employees/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = _employeeRepository.GetEmployee(id.Value);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // GET: Employees/Create
        public ActionResult Create()
        {
            ViewData["EmployeeRoleRef"] = new SelectList(_employeeRepository.GetRoles(), "RoldeId", "RoleName");
            return View();
        }

        // POST: Employees/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind("EmployeeId,FirstName,LastName,EmployeeRoleRef")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                _employeeRepository.AddEmployee(employee);
                _employeeRepository.SaveChange();
                return RedirectToAction("Index");
            }
            ViewData["EmployeeRoleRef"] = new SelectList(_employeeRepository.GetRoles(), "RoldeId", "RoleName", employee.EmployeeRoleRef);
            return View(employee);
        }

        //GET: Employees/Edit/5
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = _employeeRepository.GetEmployee(id.Value);
            if (employee == null)
            {
                return NotFound();
            }
            ViewData["EmployeeRoleRef"] = new SelectList(_employeeRepository.GetRoles(), "RoldeId", "RoleName", employee.EmployeeRoleRef);
            return View(employee);
        }

        // POST: Employees/Edit/5
        //To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, [Bind("EmployeeId,FirstName,LastName,EmployeeRoleRef")] Employee employee)
        {
            if (id != employee.EmployeeId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _employeeRepository.UpdateEmployee(employee);
                }
                catch (DbUpdateConcurrencyException)
                {
                   
                        return NotFound();
                   
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["EmployeeRoleRef"] = new SelectList(_employeeRepository.GetRoles(), "RoldeId", "RoleName", employee.EmployeeRoleRef);
            return View(employee);
        }

        // GET: Employees/Delete/5
        [Authorize]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = _employeeRepository.GetEmployee(id.Value);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Employees/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var employee = _employeeRepository.GetEmployee(id);
            _employeeRepository.RemoveEmployee(employee);
            _employeeRepository.SaveChange();
            return RedirectToAction("Index");
        }

        public ActionResult GetEmployeesInfo()
        {
            var employeeTasks = new List<vmEmployeeRates>();

            var employees = _employeeRepository.GetAllEmployees();

            foreach (var employee in employees)
            {                
                var dailyTasks = _dailyTaskRepository.GetAllTasks().Where(e => e.Employee.EmployeeId == employee.EmployeeId);

                foreach (var task in dailyTasks)
                {
                    var employeeModel = new vmEmployeeRates
                    {
                        FirstName = employee.FirstName,
                        LastName = employee.LastName,
                        RoleName = employee.EmployeeRole != null? employee.EmployeeRole.RoleName : "",
                        Rate = employee.EmployeeRole != null ? employee.EmployeeRole.Rate : 0,
                        TaskName = task.TaskDetail != null? task.TaskDetail.TaskName : "",
                        TaskDuration = task.TaskDetail != null ? task.TaskDetail.TaskDuration : 0
                    };

                    employeeTasks.Add(employeeModel);
                }  
            }
            ViewBag.EmployeeTasks = employeeTasks;
            return View();
        }
    }
}
