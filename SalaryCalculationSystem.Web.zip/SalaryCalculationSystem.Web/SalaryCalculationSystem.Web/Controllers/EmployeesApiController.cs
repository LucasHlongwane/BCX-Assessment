﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;

namespace SalaryCalculationSystem.Web.Controllers
{
   

    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesApiController : Controller
    {
        private readonly IEmployeeRepo _employeeRepository;

        public EmployeesApiController(IEmployeeRepo employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        // GET: api/EmployeesApi
        [HttpGet()]
        public IEnumerable<Employee> GetEmployees()
        {
            return _employeeRepository.GetAllEmployees();
        }

        // GET: api/EmployeesApi/5
        [HttpGet("{id}", Name = "GetEmployee")]
        public async Task<ActionResult> GetEmployee(int id)
        {
            var employee = _employeeRepository.GetEmployee(id);
            if (employee == null) return NotFound();

            return Ok(employee);
            
        }

        // POST: api/EmployeesApi
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<ActionResult> AddEmployee([FromBody] Employee employee)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            
            _employeeRepository.AddEmployee(employee);
            _employeeRepository.SaveChange();
            return Ok(employee);
        }

        // PUT: api/EmployeesApi/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<ActionResult> DeleteEmplpoyee(int id)
        {
            var employee = _employeeRepository.GetEmployee(id);
            if (employee == null) return NotFound();

            _employeeRepository.RemoveEmployee(employee);
            _employeeRepository.SaveChange();

            return NoContent();

        }
    }
}
