﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;

namespace SalaryCalculationSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DailyTasksApiController : ControllerBase
    {
        private readonly IDailyTaskRepo _dailyTaskRepo;

        public DailyTasksApiController(IDailyTaskRepo dailyTaskRepo)
        {
            _dailyTaskRepo = dailyTaskRepo;
        }

        // GET: api/EmployeesApi
        [HttpGet()]
        public IEnumerable<DailyTask> GetTasks()
        {
            return _dailyTaskRepo.GetAllTasks();
        }

        // GET: api/EmployeesApi/5
        [HttpGet("{id}", Name = "GetDailyTask")]
        public ActionResult GetTask(int id)
        {
            var task = _dailyTaskRepo.GetTask(id);
            if (task == null) return NotFound();

            return Ok(task);

        }

        // POST: api/EmployeesApi
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<ActionResult> AddTask([FromBody] DailyTask taskDetail)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);


            _dailyTaskRepo.AddTask(taskDetail);
            _dailyTaskRepo.SaveChanges();
            return Ok(taskDetail);
        }

        //// PUT: api/TasksApi/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<ActionResult> DeleteTask(int id)
        {
            var task = _dailyTaskRepo.GetTask(id);
            if (task == null) return NotFound();

            _dailyTaskRepo.RemoveTask(task);
            _dailyTaskRepo.SaveChanges();

            return NoContent();

        }
    }
}
