﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SalaryCalculationSystem.Web.Data;
using SalaryCalculationSystem.Web.Data.DataManager;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;

namespace SalaryCalculationSystem.Web.Controllers
{
    public class DailyTasksController : Controller
    {
        private readonly IDailyTaskRepo _dailyTaskRepo;
        private readonly IRoleRepo _rolesRepo;
        private readonly ITaskDetailRepo _taskDetailRepo;
        public DailyTasksController(IDailyTaskRepo dailyTaskRepo, IRoleRepo rolesRepo, ITaskDetailRepo taskDetailRepo )
        {
            _dailyTaskRepo = dailyTaskRepo;
            _rolesRepo = rolesRepo;
            _taskDetailRepo = taskDetailRepo;
        }

        // GET: DailyTasks
        public IActionResult Index()
        {
           // var applicationDbContext = _context.DailyTasks.Include(d => d.Employee).Include(d => d.TaskDetail);
            return View(_dailyTaskRepo.GetAllTasks());
        }

        // GET: DailyTasks/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dailyTask = _dailyTaskRepo.GetTask(id.Value);
            if (dailyTask == null)
            {
                return NotFound();
            }

            return View(dailyTask);
        }


        public IActionResult GetTaskByEmployee(int? id, DateTime? startdate, DateTime? enddate)
        {
            if (id == null)
            {
                return NotFound();
            }

            //get a list of tasks assigned tp a user through the DailyTaskApi repo
            var dailyTask = _dailyTaskRepo.GetTaskByEmployee(id.Value);

            if (dailyTask == null)
            {
                return NotFound();
            }

            //filter the data according to date rage
            if (startdate != null && enddate != null)
            {
              var filteredTasks =   _dailyTaskRepo.GetTaskByEmployee(id.Value).Where(x => x.AssignedOn >= startdate && x.AssignedOn <= enddate);

                //return to view with filtered data
                return View(filteredTasks);
            }

            // return to view with all data
            return View(dailyTask);
        }

        // GET: DailyTasks/Create
        public IActionResult Create()
        {
            ViewData["EmployeeRef"] = new SelectList(_dailyTaskRepo.GetEmployee(), "EmployeeId", "FirstName");
            ViewData["TaskRef"] = new SelectList(_dailyTaskRepo.GetTasks(), "TaskId", "TaskName");
            return View();
        }

        // POST: DailyTasks/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DailyTaskId,TaskRef,EmployeeRef,AssignedOn")] DailyTask dailyTask)
        {
            var employeeRate = _rolesRepo.GetAllRoles().Where(a => a.RoldeId == dailyTask.EmployeeRef).Select(r => r.Rate).FirstOrDefault();
            var allocatedTime = _taskDetailRepo.GetAllTasks().Where(a => a.TaskId == dailyTask.TaskRef).Select(d => d.TaskDuration).FirstOrDefault();
            if (ModelState.IsValid)
            {
                dailyTask.HourlyRate = employeeRate;
                dailyTask.TaskTime =  allocatedTime;

                

                _dailyTaskRepo.AddTask(dailyTask);
                _dailyTaskRepo.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewData["EmployeeRef"] = new SelectList(_dailyTaskRepo.GetEmployee(), "EmployeeId", "FirstName", dailyTask.EmployeeRef);
            ViewData["TaskRef"] = new SelectList(_dailyTaskRepo.GetTasks(), "TaskId", "TaskName", dailyTask.TaskRef);
            return View(dailyTask);
        }

        // GET: DailyTasks/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dailyTask = _dailyTaskRepo.GetTask(id.Value);
            {
                return NotFound();
            }
            ViewData["EmployeeRef"] = new SelectList(_dailyTaskRepo.GetEmployee(), "EmployeeId", "FirstName", dailyTask.EmployeeRef);
            ViewData["TaskRef"] = new SelectList(_dailyTaskRepo.GetTasks(), "TaskId", "TaskName", dailyTask.TaskRef);
            return View(dailyTask);
        }

        // POST: DailyTasks/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DailyTaskId,TaskRef,EmployeeRef,AssignedOn")] DailyTask dailyTask)
        {
            if (id != dailyTask.DailyTaskId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _dailyTaskRepo.UpdateTask(dailyTask);
                }
                catch (DbUpdateConcurrencyException)
                {
                   
                        return NotFound();
                    
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["EmployeeRef"] = new SelectList(_dailyTaskRepo.GetEmployee(), "EmployeeId", "FirstName", dailyTask.EmployeeRef);
            ViewData["TaskRef"] = new SelectList(_dailyTaskRepo.GetTasks(), "TaskId", "TaskName", dailyTask.TaskRef);
            return View(dailyTask);
        }

        // GET: DailyTasks/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dailyTask = _dailyTaskRepo.GetTask(id.Value);
            if (dailyTask == null)
            {
                return NotFound();
            }

            return View(dailyTask);
        }

        // POST: DailyTasks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var dailyTask = _dailyTaskRepo.GetTask(id);
            _dailyTaskRepo.RemoveTask(dailyTask);
            _dailyTaskRepo.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
