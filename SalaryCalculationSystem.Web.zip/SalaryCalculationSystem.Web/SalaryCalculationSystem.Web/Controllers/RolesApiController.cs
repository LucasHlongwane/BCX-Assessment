﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;

namespace SalaryCalculationSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RolesApiController : ControllerBase
    {
        private readonly IRoleRepo _roleRepo;
        public RolesApiController(IRoleRepo roleRepo)
        {
            _roleRepo = roleRepo;
        }
        // GET: api/RolesApi
        [HttpGet()]
        public IEnumerable<EmployeeRole> GetRoles()
        {
            return _roleRepo.GetAllRoles();
        }

        // GET: api/RolesApi/5
        [HttpGet("{id}", Name = "GetRole")]
        public ActionResult GetRole(int id)
        {
            var role = _roleRepo.GetRole(id);
            if (role == null) return NotFound();

            return Ok(role);

        }

        // POST: api/EmployeesApi
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult AddRole([FromBody] EmployeeRole employeeRole)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);


            _roleRepo.AddRole(employeeRole);
            _roleRepo.SaveChanges();
            return Ok(employeeRole);
        }

        // PUT: api/RolesApi/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        [ValidateAntiForgeryToken]
        [Authorize]
        public ActionResult DeleteRole(int id)
        {
            var role = _roleRepo.GetRole(id);
            if (role == null) return NotFound();

            _roleRepo.RemoveRole(role);
            _roleRepo.SaveChanges();

            return NoContent();

        }
    }
}
