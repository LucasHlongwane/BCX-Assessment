﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SalaryCalculationSystem.Web.Data;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;

namespace SalaryCalculationSystem.Web.Controllers
{
    public class TaskDetailsController : Controller
    {
        private readonly ITaskDetailRepo _taskDetailRepo;

        public TaskDetailsController(ITaskDetailRepo taskDetailRepo)
        {
            _taskDetailRepo = taskDetailRepo;
        }

        // GET: TaskDetails
        public async Task<IActionResult> Index()
        {
            return View(_taskDetailRepo.GetAllTasks());
        }

        // GET: TaskDetails/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var taskDetail = _taskDetailRepo.GetTask(id.Value);
            if (taskDetail == null)
            {
                return NotFound();
            }

            return View(taskDetail);
        }

        // GET: TaskDetails/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TaskDetails/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind("TaskId,TaskName,TaskDescription,TaskDuration")] TaskDetail taskDetail)
        {
            if (ModelState.IsValid)
            {
                _taskDetailRepo.AddTask(taskDetail);
                _taskDetailRepo.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(taskDetail);
        }

        // GET: TaskDetails/Edit/5
        //public async Task<IActionResult> Edit(int? id)
        //{
        //    if (id == null)
        //    {
        //        return NotFound();
        //    }

        //    var taskDetail = await _context.TaskDetails.FindAsync(id);
        //    if (taskDetail == null)
        //    {
        //        return NotFound();
        //    }
        //    return View(taskDetail);
        //}

        // POST: TaskDetails/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Edit(int id, [Bind("TaskId,TaskName,TaskDescription,TaskDuration")] TaskDetail taskDetail)
        //{
        //    if (id != taskDetail.TaskId)
        //    {
        //        return NotFound();
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            _context.Update(taskDetail);
        //            await _context.SaveChangesAsync();
        //        }
        //        catch (DbUpdateConcurrencyException)
        //        {
        //            if (!TaskDetailExists(taskDetail.TaskId))
        //            {
        //                return NotFound();
        //            }
        //            else
        //            {
        //                throw;
        //            }
        //        }
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(taskDetail);
        //}

        // GET: TaskDetails/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var taskDetail = _taskDetailRepo.GetTask(id.Value);
            if (taskDetail == null)
            {
                return NotFound();
            }

            return View(taskDetail);
        }

        // POST: TaskDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var taskDetail = _taskDetailRepo.GetTask(id);
            _taskDetailRepo.RemoveTask(taskDetail);
             _taskDetailRepo.SaveChanges();
            return RedirectToAction("Index");
        }

        
    }
}
