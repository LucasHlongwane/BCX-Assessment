﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalaryCalculationSystem.Web.Models
{
    public class vmEmployeeRates
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string TaskName { get; set; }
        public string RoleName { get; set; }
        public int TaskDuration { get; set; }
        public decimal Rate { get; set; }
    }
}
