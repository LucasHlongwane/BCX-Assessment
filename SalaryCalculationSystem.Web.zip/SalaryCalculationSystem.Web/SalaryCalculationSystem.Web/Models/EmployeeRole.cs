﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SalaryCalculationSystem.Web.Models
{
    public class EmployeeRole
    {
        [Key]
        public int RoldeId { get; set; }

        [Required]
        [Display(Name = "Role Name")]
        public string RoleName { get; set; }

        [Required]
        [DataType(DataType.Currency)]
        [Display(Name = "Rate Per Hour")]
        public decimal Rate { get; set; }

    }
}
