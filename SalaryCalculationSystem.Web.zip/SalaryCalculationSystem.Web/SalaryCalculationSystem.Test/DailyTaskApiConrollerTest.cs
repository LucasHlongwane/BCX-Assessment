using Microsoft.AspNetCore.Mvc;
using Moq;
using SalaryCalculationSystem.Web.Controllers;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace SalaryCalculationSystem.Test
{
    public class DailyTaskApiConrollerTest
    {
        private Mock<IDailyTaskRepo> dailytaskRepoMock;
        private DailyTasksApiController controller;

        public DailyTaskApiConrollerTest()
        {
            dailytaskRepoMock = new Mock<IDailyTaskRepo>();
            controller = new DailyTasksApiController(dailytaskRepoMock.Object);
        }


        #region Get By Id  

        [Fact]
        public async void Task_GetTaskById_Return_OkResult()
        {
            //Arrange 
            var taskId = 1;

            //Act  
            var data = controller.GetTask(taskId);

            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }

        [Fact]
        public async void Task_GetTaskById_Return_NotFoundResult()
        {
            //Arrange  
            var taskId = 3;

            //Act  
            var data = controller.GetTask(taskId);

            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }

        #endregion
    }
}
