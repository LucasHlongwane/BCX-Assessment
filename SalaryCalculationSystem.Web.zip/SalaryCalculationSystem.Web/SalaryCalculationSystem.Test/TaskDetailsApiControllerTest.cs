using Microsoft.AspNetCore.Mvc;
using Moq;
using SalaryCalculationSystem.Web.Controllers;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace SalaryCalculationSystem.Test
{
    public class TaskDetailsApiControllerTest
    {
        private Mock<ITaskDetailRepo> taskdetailrepoMock;
        private TasksApiController controller;

        public TaskDetailsApiControllerTest()
        {
            taskdetailrepoMock = new Mock<ITaskDetailRepo>();
            controller = new TasksApiController(taskdetailrepoMock.Object);

        }

        #region Get By Id  

        [Fact]
        public async void Task_GetTaskById_Return_OkResult()
        {
            //Arrange 
            var taskId = 1;

            //Act  
            var data = controller.GetTask(taskId);

            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }

        [Fact]
        public async void Task_GetTaskById_Return_NotFoundResult()
        {
            //Arrange  
            var taskId = 3;

            //Act  
            var data = controller.GetTask(taskId);

            //Assert  
            Assert.IsType<NotFoundResult>(data);
        }

        #endregion
    }
}
