using Microsoft.AspNetCore.Mvc;
using Moq;
using SalaryCalculationSystem.Web.Controllers;
using SalaryCalculationSystem.Web.Data.Repositories;
using SalaryCalculationSystem.Web.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace SalaryCalculationSystem.Test
{
    public class EmployeeApiControllerTest
    {
        private Mock<IEmployeeRepo> employeeRepoMock;
        private EmployeesApiController controller;

        public EmployeeApiControllerTest()
        {
            employeeRepoMock = new Mock<IEmployeeRepo>();
            controller = new EmployeesApiController(employeeRepoMock.Object);
        }

        [Fact]
        public async Task GetEmployeesTest_RetursEmployeesList()
        {
            // Arrange
            var mockEmployeesList = new List<Employee>
            {
                new Employee
                {
                    EmployeeId = 1,
                    FirstName = "Alexander",
                    LastName = "Carson",
                    EmployeeRoleRef = 1

                },
                new Employee
                {
                    EmployeeId = 2,
                    FirstName = "Alonso",
                    LastName = "Meredith",
                    EmployeeRoleRef = 2
                }
            };
            employeeRepoMock.Setup(repo => repo.GetAllEmployees()).Returns(mockEmployeesList);

            // Act
            var result = controller.GetEmployees();

            // Assert
             Assert.Equal(mockEmployeesList, result);
        }
        [Fact]
        public async Task GetEmployeeTest_ReturnsNotFound_WhenEmployeeDoesNotExists()
        {
            // Arrange
            var mockId = 42;
            //employeeRepoMock.Setup(repo => repo.GetEmployee(mockId)).Returns(null);

            // Act
            var result = await controller.GetEmployee(mockId);

            // Assert
            var viewResult = Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public async Task GetEmployeeTest_ReturnsDetailsView_WhenEmployeeExists()
        {
            // Arrange
            var mockId = 42;
            var mockEmplpyee = new Employee
            {
                EmployeeId = 1,
                FirstName = "Alexander",
                LastName = "Carson",
                EmployeeRoleRef = 1,
            };
            employeeRepoMock.Setup(repo => repo.GetEmployee(mockId)).Returns(mockEmplpyee);

            // Act
            var result = await controller.GetEmployee(mockId);

            // Assert
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(mockEmplpyee, actionResult.Value);
        }

        [Fact]
        public async Task AddEmployeeTest_Post_ReturnsCreateView_WhenModelStateIsInvalid()
        {
            // Arrange
            var mockEmployee = new Employee
            {
                EmployeeId = 1,
                FirstName = "Alexander",
                LastName = "St. Patrick",
                EmployeeRoleRef = 1,
            };
            controller.ModelState.AddModelError("Last Name", "This field is required");

            // Act
            var result = await controller.AddEmployee(mockEmployee);

            // Assert
            var actionResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal(new SerializableError(controller.ModelState), actionResult.Value);
        }

        [Fact]
        public async Task AddEmployeeTest_Post_ReturnsEmployeeSuccessfullyAdded()
        {
            // Arrange
            var mockEmployee = new Employee
            {
                EmployeeId = 1,
                FirstName = "Alexander",
                LastName = "Norwood",
                EmployeeRoleRef = 1,
            };

            // Act
            var result = await controller.AddEmployee(mockEmployee);

            // Assert
            employeeRepoMock.Verify(repo => repo.AddEmployee(mockEmployee));
            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(mockEmployee, actionResult.Value);
        }

        [Fact]
        public async Task DeleteEmployee()
        {
            var employeeId = 2;

            //Act
            var result = await controller.DeleteEmplpoyee(employeeId);

            //Assert
            Assert.IsType<NotFoundResult>(result);
        }
    }
}
